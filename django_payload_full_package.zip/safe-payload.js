// safe-payload.js - simulated safe test payload
console.log("✅ Safe payload loaded from GitHub Pages.");
alert("🔐 Đây là mã giả lập payload an toàn để kiểm tra WAF/trình duyệt.");